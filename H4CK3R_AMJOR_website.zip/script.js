function checkLogin() {
  const input = document.getElementById("loginInput").value;
  const msg = document.getElementById("loginMessage");
  const anim = document.getElementById("accessAnimation");

  if (input === "amjor123") {
    anim.className = "access-show";
    setTimeout(() => window.location.href = "index.html", 2000);
  } else {
    msg.innerText = "Access Denied";
  }
}

const termInput = document.getElementById("terminalInput");
const termOutput = document.getElementById("terminalOutput");

if (termInput) {
  termInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const cmd = termInput.value.toLowerCase();
      termOutput.innerHTML += "<div>> " + cmd + "</div>";

      if (cmd === "help") {
        termOutput.innerHTML += "<div>commands: help, ping, clear, version</div>";
      } else if (cmd === "ping") {
        termOutput.innerHTML += "<div>Reply from 127.0.0.1: time=1ms</div>";
      } else if (cmd === "version") {
        termOutput.innerHTML += "<div>H4CK3R AMJOR Terminal v1.0</div>";
      } else if (cmd === "clear") {
        termOutput.innerHTML = "";
      } else {
        termOutput.innerHTML += "<div>Unknown command</div>";
      }

      termInput.value = "";
      termOutput.scrollTop = termOutput.scrollHeight;
    }
  });
}
